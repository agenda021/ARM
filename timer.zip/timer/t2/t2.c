#include <LPC214X.H>
void timer(void);
__irq void timer_isr_t0()
{
T0IR=0x01;
timer();
IO0SET=0x00010000;
timer();
IO0CLR=0x00010000;
timer();
VICVectAddr=0x00;
}
int main()
{
VPBDIV=0x00;
PINSEL0=0x00000000;
PINSEL1=0x00000000;
IO0DIR=0x00ff0000;
VICIntSelect=0x00000000;
VICIntEnable=0x00000010;
VICVectCntl0=0x00000024;
VICVectAddr0=(unsigned long)timer_isr_t0;
timer();
while(1);
}

void timer()
{
T0TCR=0X01;
T0TC=0X00000000;
T0MR0=0X00003B2F;
T0PR=0X000003E8;
T0MCR=0X0003;
while(T0MR0!=T0TC);
}
