#include <LPC214X.H>
void timer(void);
int main()
{
VPBDIV=0x00;
IO0DIR=0x00ff0000;
while(1)
{
IO0SET=0x00400000;
timer();
IO0CLR=0x00400000;
timer();
}
}
void timer()
{
T0TCR=0x01;
 T0TC=0x00000000;
T0MR0=0x00003B2F;
T0PR=0x000003E8;
T0MCR=0x0003;
while(T0MR0!=T0TC);
}
