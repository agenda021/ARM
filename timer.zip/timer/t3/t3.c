#include <LPC214X.H>
void timer(void);
unsigned int arr1[]={0x00010000,0x00020000,0x00040000,0x00080000,0x00100000,0x00200000,0x00400000,0x00800000};
unsigned int arr2[]={0x00800000,0x00400000,0x00200000,0x00100000,0x00080000,0x00040000,0x00020000,0x00010000};

__irq void timer_isr_t0()
{
unsigned int m;
T0IR=0x01;
timer();
for(m=0;m<8;m++)
{
IO0SET=arr1[m];
timer();
IO0CLR=arr1[m];
timer();
}

for(m=0;m<8;m++)
{
IO0SET=arr2[m];
timer();
IO0CLR=arr2[m];
timer();
}

VICVectAddr=0x00;
}
int main()
{
VPBDIV=0x00;
PINSEL0=0x00000000;
PINSEL1=0x00000000;
IO0DIR=0x00ff0000;
VICIntSelect=0x00000000;
VICIntEnable=0x00000010;
VICVectCntl0=0x00000024;
VICVectAddr0=(unsigned long)timer_isr_t0;
timer();
while(1);
}

void timer()
{
T0TCR=0X01;
T0TC=0X00000000;
T0MR0=0X00003B2F;
T0PR=0X000003E8;
T0MCR=0X0003;
while(T0MR0!=T0TC);
}

