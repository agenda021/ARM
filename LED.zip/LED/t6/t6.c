#include <LPC214X.H>
void delay(unsigned int t);
unsigned int arr1[]={0x00010000,0x00020000,0x00040000,0x00080000,0x00100000,0x00200000,0x00400000,0x00800000};
unsigned int arr2[]={0x00800000,0x00400000,0x00200000,0x00100000,0x00080000,0x00040000,0x00020000,0x00010000};
int main()
{
unsigned int m;
VPBDIV=0X00;
IO0DIR=0X00FF0000;
while(1)
{
for(m=0;m<8;m++)
{
IO0SET=arr1[m];
delay(3000);
IO0CLR=arr1[m];
delay(3000);
}
for(m=0;m<8;m++)
{
IO0SET=arr2[m];
delay(3000);
IO0CLR=arr2[m];
delay(3000);
}
}
}
void delay(unsigned int t)
{
unsigned int i,j;
for(i=0;i<t;i++)
for(j=0;j<120;j++);
}
