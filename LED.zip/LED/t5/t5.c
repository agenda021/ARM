#include <LPC214X.H>
void delay(unsigned int t);
void action(void);
int main()
{
VPBDIV=0X00;
IO0DIR=0x00FF0000;
while(1)
{
action();
}
}
void action(void)
{
IO0SET=0X00800000;
delay(3000);
IO0CLR=0X00800000;
delay(3000);
IO0SET=0X00400000;
delay(3000);
IO0CLR=0x00400000;
delay(3000);
IO0SET=0X00200000;
delay(3000);
IO0CLR=0X00200000;
delay(3000);
IO0SET=0X00100000;
delay(3000);
IO0CLR=0x00100000;
delay(3000);
IO0SET=0X00080000;
delay(3000);
IO0CLR=0X00080000;
delay(3000);
IO0SET=0X00040000;
delay(3000);
IO0CLR=0x00040000;
delay(3000);
IO0SET=0X00100000;
delay(3000);
IO0CLR=0X00100000;
delay(3000);
IO0SET=0X00080000;
delay(3000);
IO0CLR=0X00080000;
delay(3000);
}
void delay(unsigned int t)
{
unsigned int i,j;
for(i=0;i<t;i++)
for(j=0;j<500;j++);
}

