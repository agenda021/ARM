#include <LPC214X.H>
void delay(unsigned int t);
int main()
{
unsigned int m,i;
VPBDIV=0X00;
IO0DIR=0x00FF0000;
while(1)
{
m=0x00800000;
for(i=0;i<8;i++)
{
IO0SET=m;
delay(3000);
IO0CLR=m;
m=m>>1;
}
m=0x00010000;
for(i=0;i<8;i++)
{
IO0SET=m;
delay(3000);
IO0CLR=m;
m=m<<1;
}
}
}
void delay(unsigned int t)
{
unsigned int i,j;
for(i=0;i<t;i++)
for(j=0;j<500;j++);
}
