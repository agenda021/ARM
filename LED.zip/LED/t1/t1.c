#include <LPC214X.H>
void delay(void );
int main()
{
VPBDIV=0x00;
IO0DIR=0x00FF0000;
while(1)
{
IO0SET=0x00800000;
delay();
IO0CLR=0x00ff0000;
delay();
}
}
void delay()
{
unsigned int i;
for(i=0;i<6000000;i++);
}
