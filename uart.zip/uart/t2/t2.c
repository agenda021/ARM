#include <LPC214X.H>
void init_uart(void);
unsigned char rx(void);
void tx(unsigned char z);
void incr(void);
void display(void);
unsigned char look_up[]={"0123456789"};
unsigned char ds1,ds2,ds3,ds4,ds5;
void delay(unsigned int t);

int main(void)
{
VPBDIV=0x00;
PINSEL0=0x00000005;
IO0DIR=0x000000001;
init_uart();
ds1=ds2=ds3=ds4=0;
while(1)
{
display();
delay(100);
incr();
}
}

void init_uart(void)
{
U0FCR=0x07;
U0LCR=0x83;
U0DLL=98;
U0LCR=0x03;
}

void incr()
{
ds1++;
if(ds1==9+1)
 {
  ds1=0;
  ds2++;
  if(ds2==9+1)
  {
   ds2=0;
   ds3++;
   if(ds3==9+1)
   {
    ds3=0;
	ds4++;
	if(ds4==9+1)
	ds4=0;
	}
   }
  }
 }

void display()
{
 tx(look_up[ds4]);
 delay(5);
 tx(look_up[ds3]);
 delay(5);
 tx(look_up[ds2]);
 delay(5);
 tx(look_up[ds1]);
 delay(5);
}

void tx(unsigned char z)
{
while((U0LSR&0x20)==0x00)
{
}
U0THR=z;
}

unsigned char rx(void)
{
unsigned char d;
while((U0LSR&0x01)==0x00)
{
}
d=U0RBR;
return(d);
}

void delay(unsigned int t)
{
unsigned int i,j;
for(i=0;i<t;i++)
for(j=0;j<120;j++);
}

