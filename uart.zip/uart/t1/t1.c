#include <LPC214X.H>
void init_uart(void);
unsigned char rx(void);
void tx(unsigned char z);

int main(void)
{
unsigned char z;
VPBDIV=0x00;
PINSEL0=0x00000005;
IO0DIR=0x000000001;
init_uart();
tx('H');
tx('A');
tx('R');
tx('I');
tx('T');
tx('A');
while(1)
{
z=rx();
tx(z);
}
}

void init_uart(void)
{
U0FCR=0x07;
U0LCR=0x83;
U0DLL=98;
U0LCR=0x03;
}

void tx(unsigned char z)
{
while((U0LSR&0x20)==0x00)
{
}
U0THR=z;
}

unsigned char rx(void)
{
unsigned char d;
while((U0LSR&0x10)==0x00)
{
}
d=U0RBR;
return(d);
}

