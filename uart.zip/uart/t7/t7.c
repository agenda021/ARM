#include <LPC214X.H>
void init_uart(void);
void rx(void);
void uart_tx(unsigned char);
void uart_delay(unsigned int);
unsigned char ds1,a;
void init_uart(void);
void init_lcd(void);
void toggle(void);
void cmdwr(unsigned int val);
void datawr(unsigned int val1);
void delay(unsigned int t);
int temp;

int main(void)
{
//unsigned char z;
VPBDIV=0x00;
PINSEL0=0x00000005;
IO0DIR=0x00FF0000;
init_uart();
init_lcd();
while(1)
{
//rx();
uart_tx(temp);
//uart_delay(500);
datawr(temp);
}
}

void init_lcd()
{
delay(18);
cmdwr(0x03);
delay(1);
cmdwr(0x03);
delay(1);
cmdwr(0x03);
delay(1);
cmdwr(0x02);
delay(1);
cmdwr(0x28);
delay(1);
cmdwr(0x10);
delay(1);
cmdwr(0x06);
delay(1);
cmdwr(0x0e);
delay(1);
cmdwr(0x01);
delay(1);
IO0CLR=0X00010000;
}

void cmdwr(unsigned int ch)
{
delay(10);
IO0CLR=0x00ff0000;
IO0SET=(ch&0xf0)<<16;
IO0SET=0x00080000;
toggle();
IO0CLR=0x00080000;
IO0CLR=0x00ff0000;
IO0SET=(ch&0x0f)<<20;
IO0SET=0x00080000;
toggle();
IO0CLR=0x00080000;
}

void datawr(unsigned int ch1)
{
delay(10);
IO0CLR=0x00ff0000;
IO0SET=0x00020000;
IO0CLR=0x00f00000;
IO0SET=(ch1&0xf0)<<16;
IO0SET=0x00080000;
toggle();
IO0CLR=0x00080000;
IO0CLR=0x00f00000;
IO0SET=(ch1&0x0f)<<20;
IO0SET=0x00080000;
toggle();
IO0CLR=0x00080000;
}
void toggle(void)
 {
 IO0SET=0x00080000;
 delay(6);
 IO0CLR=0x00080000;
 }
void delay(unsigned int t)
{
unsigned int i,j;
for(i=0;i<t;i++)
{
for(j=0;j<=1500;j++);
}
}

void init_uart(void)
{
U0FCR=0x07;
U0LCR=0x83;
U0DLL=98;
U0LCR=0x03;
}


void uart_tx(unsigned char ch)
{
	 while(U0LSR==0X20);	
	 U0THR=ch;
	 U0LSR=0X20;
 }

void rx()

 {
	while((U0LSR&0X01)==0);

	temp=U0RBR;
	
	}
void uart_delay(unsigned int n)
{
		unsigned int k,j;
	
	 	for (k=0;k<=n;k++)
			for (j=0;j<=255;j++);
}
