#include <LPC214X.H>
#include<stdio.h>
void init_uart(void);
unsigned char rx(void);
void tx(unsigned char z);
void lcd(void);
void datawr(unsigned int);
void cmdwr(unsigned int);
void delay(unsigned int);
unsigned char a[]="HARITA BHOSLE";
unsigned int i,j;

int main(void)
{
//unsigned char z;
VPBDIV=0x00;
//PINSEL0=0x00000005;
IO0DIR=0x00ff0000;
init_uart();
lcd();
cmdwr(0x80);
delay(50);
for(i=0;i<13;i++)
{
datawr(a[i]);
delay(10);
}
while(1);
}

void lcd()
{
delay(18);
cmdwr(0x03);
delay(1);
cmdwr(0x03);
delay(1);
cmdwr(0x03);
delay(1);
cmdwr(0x02);
delay(1);
cmdwr(0x28);
delay(1);
cmdwr(0x10);
delay(1);
cmdwr(0x06);
delay(1);
cmdwr(0x0e);
delay(1);
cmdwr(0x01);
delay(1);
IO0CLR=0X00010000;
}

void cmdwr(unsigned int val)
{
delay(10);
IO0CLR=0x00ff0000;
IO0SET=(val&0xf0)<<16;
IO0SET=0x00080000;
delay(1);
IO0CLR=0x00080000;
IO0CLR=0x00ff0000;
IO0SET=(val&0x0f)<<20;
IO0SET=0x00080000;
delay(1);
IO0CLR=0x00080000;
}

void datawr(unsigned int val1)
{
delay(10);
IO0CLR=0x00ff0000;
IO0SET=0x00020000;
IO0CLR=0x00f00000;
IO0SET=(val1&0xf0)<<16;
IO0SET=0x00080000;
delay(10);
IO0CLR=0x00080000;
IO0CLR=0x00f00000;
IO0SET=(val1&0x0f)<<20;
IO0SET=0x00080000;
delay(10);
IO0CLR=0x00080000;
}

void init_uart(void)
{
U0FCR=0x07;
U0LCR=0x83;
U0DLL=98;
U0LCR=0x03;
}

void tx(unsigned char z)
{
while((U0LSR&0x20)==0x00)
{
}
U0THR=z;
}

unsigned char rx(void)
{
unsigned char d;
while((U0LSR&0x10)==0x00)
{
}
d=U0RBR;
return(d);
}

void delay(unsigned int t)
{
unsigned int i,j;
for(i=0;i<t;i++)
{
for(j=0;j<=1500;j++);
}
}
