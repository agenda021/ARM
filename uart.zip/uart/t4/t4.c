#include <LPC214X.H>
unsigned int cy,key_ready,nkp,start_sw,ovr_bit,count,scan_no,ds1,ds2,ds3,ds4,krcount,dcount,key_code,cnt_1sl,cnt_1sh,carry,m;
unsigned int ascii[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
unsigned int look_up[]={0x00fc0000,0x00600000,0x00da0000,0x00f20000,0x00660000,0x00b60000,0x00be0000,0x00e00000,0x00fe0000,0x00f60000};

	void init_timer0(void);
	void init(void);
	void key_routine(void);
	void init_timer0(void);
	void init_keypad(void);
	void init_display(void);
	void scanner(void);
	void delay(unsigned int);
    void key_release(void);
	void get_key(void);
	void disp_sw(void);
	void disp_blank(void);
	void keyprocess(void);
	void get_key(void);
	void process_a(void);
	void process_b(void);
	void process_c(void);
	void delay_1sec(void);
	void init_delay_1sec(void);
	void keyprocess(void);
	void out_debounce(void);
	void delay_1sec(void);
	void init_uart(void);
	void inc_d(void);
    unsigned char rx(void);
    void uart_tx(unsigned char);
	void uart_disp(void);
	
	__irq void timer_isrt0()
	{	
		T0IR=0x01;
		init_timer0();
		delay_1sec();
		scanner();
		if(ovr_bit==1)
		{
		 	inc_d();
			ovr_bit=0;
		}
		VICVectAddr=0x00;
	}

	int main()
	{

		VPBDIV=0X00;
 		PINSEL0=0X00000005;
 		IO0DIR=0X00FF0000;

 		VICIntSelect=0x00;
 		VICIntEnable=0x00000010;
 		VICVectCntl0=0x00000024;
 		VICVectAddr0=(unsigned long)timer_isrt0;
		init_uart();
		ds1='0';
		uart_tx( ds1);
		ds2='0';
		uart_tx( ds2);
		ds3='0';
		uart_tx( ds3);
		ds4='0';
		uart_tx( ds4);
	  

  
//		zero_disp();
		init();
	

		while(1)
		{
			get_key();
			keyprocess();
		
		}
		
	}
		
	void init()
	{
		init_timer0();
		init_keypad();
		init_delay_1sec();
	}


	
	void init_keypad()
	{
		IO1DIR=0x00FF0000;
		scan_no=0;
		dcount=33;
		krcount=32;
		key_ready=0;
		nkp=0;
		
	}

	void init_timer0()
	{
		T0TCR=0X01;
 		T0CTCR=0X00;
 		T0TC=0X00000000;
 		T0MR0=0X00003B2F;
		T0MCR=0X0007;
	}

	void key_release()
	{
	 	while(nkp==0);
		key_ready=0;
		nkp=0;
	}
   void get_key()
	{
		while(key_ready==0);
		key_code=ascii[key_code];
	}
	void init_delay_1sec()
	{
		cnt_1sl=0xe8;
		cnt_1sh=0x04;
		ovr_bit=1;
	}

	void delay_1sec()
	{
	 	if(ovr_bit==0)	
		{
		 	while(cnt_1sl)
			{
				cnt_1sl--;
				goto out_ds1sec;
			}
			while(cnt_1sh)
			{
				cnt_1sh--;
				goto reinit_1sl; 	
			}

			cnt_1sh=0x04;
			cnt_1sl=0xe8;
			ovr_bit=1;
		} 
		reinit_1sl:
			cnt_1sl=0xff;		

		out_ds1sec:;
	}



void scanner()
{
switch(scan_no)
{
case 0: IO1DIR=0x00010000;
       IO1CLR=0x00010000;
	   IO1SET=0x000E0000;
	   m=IO1PIN;
	   //IO0PIN=look_up[ds1-'0'];
	   cy=(m&0x00100000)>>20;
	   key_routine();
	   scan_no++;
	   break;

case 1: m=IO1PIN;
       cy=(m&0x00200000)>>21;
	   key_routine();
	   scan_no++;
	   break;

case 2: m=IO1PIN;
       cy=(m&0x00400000)>>22;
	   key_routine();
	   scan_no++;
	   break;

case 3: m=IO1PIN;
       cy=(m&0x00800000)>>23;
	   key_routine();
	   disp_blank();
	   scan_no++;
	   break;

case 4: IO1DIR=0x00020000;
       IO1CLR=0x00020000;
	   IO1SET=0x000D0000;
	   m=IO1PIN;
	   //IO0PIN=look_up[ds2-'0'];
	   cy=(m&0x00100000)>>20;
	   key_routine();
	   scan_no++;
	   break;

case 5: m=IO1PIN;
       cy=(m&0x00200000)>>21;
	   key_routine();
	   scan_no++;
	   break;

case 6: m=IO1PIN;
       cy=(m&0x00400000)>>22;
	   key_routine();
	   scan_no++;
	   break;

case 7: m=IO1PIN;
       cy=(m&0x00800000)>>23;
	   key_routine();
	   disp_blank();
	   scan_no++;
	   break;

case 8: IO1DIR=0x00040000;
       IO1CLR=0x00040000;
	   IO1SET=0x000B0000;
	   m=IO1PIN;
	   //IO0PIN=look_up[ds3-'0'];
	   cy=(m&0x00100000)>>20;
	   key_routine();
	   scan_no++;
	   break;

case 9: m=IO1PIN;
       cy=(m&0x00200000)>>21;
	   key_routine();
	   scan_no++;
	   break;

case 10: m=IO1PIN;
       cy=(m&0x00400000)>>22;
	   key_routine();
	   scan_no++;
	   break;

case 11: m=IO1PIN;
       cy=(m&0x00800000)>>23;
	   key_routine();
	   disp_blank();
	   scan_no++;
	   break;

case 12:IO1DIR=0x00080000;
       IO1CLR=0x00080000;
	   IO1SET=0x00070000;
	   m=IO1PIN;
	   //IO0PIN=look_up[ds4-'0'];
	   cy=(m&0x00100000)>>20;
	   key_routine();
	   scan_no++;
	   break;

case 13: m=IO1PIN;
       cy=(m&0x00200000)>>21;
	   key_routine();
	   scan_no++;
	   break;

case 14: m=IO1PIN;
       cy=(m&0x00400000)>>22;
	   key_routine();
	   scan_no++;
	   break;

case 15: m=IO1PIN;
       cy=(m&0x00800000)>>23;
	   key_routine();
	   disp_blank();
	   scan_no=0;
	   break;
	}
   }
void disp_blank()
{
	 IO0CLR=0x00FF0000;
}
//key_routine

void key_routine()
{
	if(key_ready==1)
			out_debounce();
	else
	{
		if(dcount==33)
		{
			if(cy==1)
					goto out_k;
			else
			{
				dcount--;
				key_code=scan_no;
				goto out_k;
			}
		}
		else
		{
			dcount--;
			if(dcount==0)
			{
				if(cy==1)
				{
					dcount=33;
					goto out_k;
				}
				else
				{
					dcount=33;
					key_ready=1;
			//start_buzzer=1;
					goto out_k;
				}
			}
			else
			{
				goto out_k;
			}
		}

	}
	out_k:{};
}

void out_debounce()
{
	if(cy==1)
	{
		krcount--;
		if(krcount==0)
		{
			nkp=1;
		//start_buzzer=0;
			krcount=32;
			goto out_k;
		}
		else
			goto out_k;
	}
	else
	{
			krcount=32;
			goto out_k;
	}
	out_k:{};
}

 
	void inc_d()
	{
		if (start_sw==0)
		goto out_id;
		ds1++;
		if (ds1>'9')
		  {
			ds1='0';
			ds2++;
			if(ds2>'9')
				{
					ds2='0';
					ds3++;
					if(ds3>'9')
						{
							ds3='0';
							ds4++;
							if(ds4>'9')
								{
									ds1='0';
							       	ds2='0';
									ds3='0';
									ds4='0';
								}
							}
					}
			}
	out_id:uart_disp();
	} 	

	void uart_disp()
	{	 	
	
		uart_tx(ds4);
		uart_tx(ds3);
		uart_tx(ds2);
		uart_tx(ds1);
	}

	void keyprocess()
	{
	 	if(key_code=='A')
		{
		 	process_a();
			goto out_kp;
		}

		if(key_code=='B')
		{
		 	process_b();
			goto out_kp;
		}

		if(key_code=='C')
		{
		 	process_c();
			goto out_kp;
		}

		key_release();
	
	out_kp:;
	}

	void process_a()
	{
	 	start_sw=1;
	}

	void process_b()
	{
	 	start_sw=0;
	}
	
	void process_c()
	{
	 	start_sw=0;
		ds1='0';
		ds2='0';
		ds3='0';
		ds4='0';
	}





void init_uart(void)
{
U0FCR=0x07;
U0LCR=0x83;
U0DLL=97;
U0LCR=0x03;
}

void uart_tx(unsigned char ch)
{
while(U0LSR==0X20);
U0THR=ch;
	 U0LSR=0X20;
}


  




