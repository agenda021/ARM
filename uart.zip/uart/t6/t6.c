#include <LPC214X.H>
unsigned int ds1,ds2,ds3,ds4;
unsigned int key_code,temp,scan_no,dcount,krcount,m;
unsigned int cy,nkp,key_ready;

unsigned int ascii_tab[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
unsigned int look_up[]={0x00fc0000,0x00600000,0x00da0000,0x00f20000,0x00660000,0x00b60000,0x00be0000,0x00e00000,0x00fe0000,0x00f60000,0x00000000,0x00000000,0x00000000,0x00000000,0x00000000,0x00000000,0x00000000,0x00ee0000,0x003e0000,0x009c0000,0x007a0000,0x009e0000,0x008e0000};
void init_keypad(void);
void uart_delay(unsigned int n);
void timer(void);
void key_release(void);
void scanner(void);
void key_routine(void);
void out_debounce(void);
void disp_blank(void);
void out_k(void);
void init_uart(void);
unsigned char rx(void);
void uart_tx(unsigned char);
void uart_delay(unsigned int);

__irq void timer_isr_t0()
{
T0IR=0x01;
timer();
scanner();
VICVectAddr=0x00000000;
}

int main()
{
VPBDIV=0x00;
PINSEL0=0X00000005;
IO0DIR=0x00FF0000;
VICIntSelect=0x00000000;
VICIntEnable=0x00000010;
VICVectCntl0=0x00000024;
VICVectAddr0=(unsigned long)timer_isr_t0;
init_keypad();
//unsigned char z;
init_uart();
timer();
ds1=ds2=ds3=ds4='0';
while(1)
{
while(key_ready==0);
ds1=ascii_tab[key_code];
uart_tx(ds1);
uart_delay(500);
key_release();
}
}


void init_keypad()
{
IO1DIR=0x00F00000;
scan_no=0;
key_code=0;
dcount=33;
krcount=32;
key_ready=0;
nkp=0;
}

void timer()
{
T0TCR=0x01;
T0CTCR=0x00;
T0TC=0x00000000;
T0MR0=0x00003B2F;
T0PC=0x00000000;
T0MCR=0x0007;
}
void key_release()
{
while(nkp==0);
key_ready=0;
nkp=0;
}

void scanner()
{
switch(scan_no)
{
case 0: IO1DIR=0x00010000;
       IO1CLR=0x00010000;
	   IO1SET=0x000E0000;
	   m=IO1PIN;
	   //IO0PIN=look_up[ds1-'0'];
	   cy=(m&0x00100000)>>20;
	   key_routine();
	   scan_no++;
	   break;

case 1: m=IO1PIN;
       cy=(m&0x00200000)>>21;
	   key_routine();
	   scan_no++;
	   break;

case 2: m=IO1PIN;
       cy=(m&0x00400000)>>22;
	   key_routine();
	   scan_no++;
	   break;

case 3: m=IO1PIN;
       cy=(m&0x00800000)>>23;
	   key_routine();
	   disp_blank();
	   scan_no++;
	   break;

case 4: IO1DIR=0x00020000;
       IO1CLR=0x00020000;
	   IO1SET=0x000D0000;
	   m=IO1PIN;
	   //IO0PIN=look_up[ds2-'0'];
	   cy=(m&0x00100000)>>20;
	   key_routine();
	   scan_no++;
	   break;

case 5: m=IO1PIN;
       cy=(m&0x00200000)>>21;
	   key_routine();
	   scan_no++;
	   break;

case 6: m=IO1PIN;
       cy=(m&0x00400000)>>22;
	   key_routine();
	   scan_no++;
	   break;

case 7: m=IO1PIN;
       cy=(m&0x00800000)>>23;
	   key_routine();
	   disp_blank();
	   scan_no++;
	   break;

case 8: IO1DIR=0x00040000;
       IO1CLR=0x00040000;
	   IO1SET=0x000B0000;
	   m=IO1PIN;
	   //IO0PIN=look_up[ds3-'0'];
	   cy=(m&0x00100000)>>20;
	   key_routine();
	   scan_no++;
	   break;

case 9: m=IO1PIN;
       cy=(m&0x00200000)>>21;
	   key_routine();
	   scan_no++;
	   break;

case 10: m=IO1PIN;
       cy=(m&0x00400000)>>22;
	   key_routine();
	   scan_no++;
	   break;

case 11: m=IO1PIN;
       cy=(m&0x00800000)>>23;
	   key_routine();
	   disp_blank();
	   scan_no++;
	   break;

case 12:IO1DIR=0x00080000;
       IO1CLR=0x00080000;
	   IO1SET=0x00070000;
	   m=IO1PIN;
	  // IO0PIN=look_up[ds4-'0'];
	   cy=(m&0x00100000)>>20;
	   key_routine();
	   scan_no++;
	   break;

case 13: m=IO1PIN;
       cy=(m&0x00200000)>>21;
	   key_routine();
	   scan_no++;
	   break;

case 14: m=IO1PIN;
       cy=(m&0x00400000)>>22;
	   key_routine();
	   scan_no++;
	   break;

case 15: m=IO1PIN;
       cy=(m&0x00800000)>>23;
	   key_routine();
	   disp_blank();
	   scan_no=0;
	   break;
	}
   }

void disp_blank()
{
IO0CLR=0x00FF0000;
}

void key_routine()
{
if(key_ready==1)
out_debounce();
 else
   {
    if(dcount==33)
	 {
	  if(cy==1)
	  out_k();
	  else
	    {
		dcount--;
		key_code=scan_no;
		out_k();
		}
	   }
	  else
	  {
	   dcount--;
	   if(dcount==0)
	   {
	   if(cy==1)
	   {
	    dcount=33;
		out_k();
		}
	   else
	   {
	    dcount=33;
		key_ready=1;
		out_k();
		}
	   }
	  else
	  {
	  out_k();
	  }
	 }
	}
}

void out_debounce()
{
if(cy==1)
{
krcount--;
 if(krcount==0)
 {
  nkp=1;
  krcount=32;
  out_k();
  }
  else
   out_k();
   }
   else
   {
   krcount=32;
   out_k();
   }
   }
   void out_k()
   {
   }   


void init_uart(void)
{
U0FCR=0x07;
U0LCR=0x83;
U0DLL=97;
U0LCR=0x03;
}


void uart_delay(unsigned int n)
{

	unsigned int k,j;
	
	for (k=0;k<=n;k++)
	for (j=0;j<=255;j++);
}

void uart_tx(unsigned char ch)
{
	 while(U0LSR==0X20);
	 U0THR=ch;
	 U0LSR=0X20;
 }


