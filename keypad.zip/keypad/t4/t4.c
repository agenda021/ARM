#include <LPC214X.H>
unsigned int ds1,ds2,ds3,ds4;
unsigned int  key_code, temp ,scan_no,dcount,krcount,m;
unsigned int cy,start_count,ovr_bit,count,krcount,dcount,cnt_1sl,cnt_1sh,carry,m;
unsigned int cy, nkp, key_ready;
unsigned char ascii_tab[]={"0123456789ABCDEF"};
unsigned char msg1[9]={"STOPWATCH"};
void init_keypad(void);
void timer(void);
void key_release(void);
void scanner(void);
void key_routine(void);
void out_debounce(void);
void disp_blank(void);
void out_k(void);  
void message(void);
void init_lcd(void);
void delay_1ms(unsigned int t);
void lcd_cw(unsigned int);
void lcd_dw(unsigned int);
void enable(void);
void lcd_display(void);
void count_process(void);
void delay_1sec(void);
void init_delay_1sec(void);
void key_process(void);

__irq void timer_isr_t0()
{
T0IR=0x01;
timer();
delay_1sec();
scanner();
if(ovr_bit==1)
{
 count_process();
 ovr_bit=0;
}
VICVectAddr=0x00000000;
}

int main()
{
VPBDIV=0x00;
IO0DIR=0x00ff0000;
VICIntSelect=0x00000000;
VICIntEnable=0x00000010;
VICVectCntl0=0x00000024;
VICVectAddr0=(unsigned long)timer_isr_t0;
init_keypad();
timer();
init_keypad();
init_delay_1sec();
init_lcd();
message();
ds1=ds2=ds3=ds4='0';
lcd_cw(0x01);
delay_1ms(5); 
  		  
	while(1)
	{
		while(key_ready==0)
		{
			lcd_display();
		}
		key_process();
		}
	}
				

void message()
{
 unsigned int i;
 lcd_cw(0x80);
 delay_1ms(1);
 for (i=0;i<9;i++)
 {
 lcd_dw(msg1[i]);
 delay_1ms(5);
 }
}

void init_keypad()
{
IO1DIR=0x00f00000;
scan_no=0;
key_code=0;
dcount=33;
krcount=32;
key_ready=0;
nkp=0;
}

void timer()
{
T0TCR=0x01;
T0CTCR=0x00;
T0TC=0x00000000;
T0MR0=0x00003B2F;
T0PC=0x00000000;
T0MCR=0x0007;
}
void key_release()
{
while(nkp==0);
key_ready=0;
nkp=0;
}

void lcd_display()
{
	lcd_cw(0xc5);
	delay_1ms(1);
    lcd_dw(ds4);
	delay_1ms(10);
	lcd_dw(ds3);
	delay_1ms(10);
	lcd_dw(ds2);
	delay_1ms(10);
	lcd_dw(ds1);
	delay_1ms(10);
    lcd_cw(0x02);
  	delay_1ms(1);
}

void init_delay_1sec()
	{
	cnt_1sl=0xe8;
	cnt_1sh=0x04;
	ovr_bit=1;
	}

void delay_1sec()
	{
	 if(ovr_bit==0)	
	{
	while(cnt_1sl)
	{
	cnt_1sl--;
	goto out_ds1sec;
	}
	while(cnt_1sh)
	{
	cnt_1sh--;
	goto reinit_1sl; 	
	}
    cnt_1sh=0x04;
	cnt_1sl=0xe8;
	ovr_bit=1;
} 
	reinit_1sl:
	cnt_1sl=0xff;		
	out_ds1sec:;
}

void count_process()
{
if (start_count==1)
	{
	ds1++;
	if (ds1=='9'+1)
		 {
		  ds1='0';
		  ds2++;
		  if(ds2=='9'+1)
			{
			 ds2='0';
			 ds3++;
			 if(ds3=='9'+1)
				{
				  ds3='0';
					 ds4++;
					 if(ds4=='9'+1)
						{
							ds1=ds2=ds3=ds4='0';     	
						}
					}
				}
			}
	}
	else 
		goto out_id;
	out_id:;
	} 	

	
void key_process()
	{
	 	if(ascii_tab[key_code]=='A')
		{
		 	start_count=1;
			key_release();
			goto out_kp;
		}

		else if(ascii_tab[key_code]=='B')
		{
		 	start_count=0;
			key_release();
			goto out_kp;
		}

		else if(ascii_tab[key_code]=='C')
		{
		 	start_count=0;
			key_release();
			ds1=ds2=ds3=ds4='0';
			goto out_kp;
		}
	
	out_kp:;
	}



void scanner()
{
switch(scan_no)
{
case 0: IO1DIR=0x00010000;
       IO1CLR=0x00010000;
	   IO1SET=0x000E0000;
	   m=IO1PIN;
	   //IO0PIN=look_up[ds1-'0'];
	   cy=(m&0x00100000)>>20;
	   key_routine();
	   scan_no++;
	   break;

case 1: m=IO1PIN;
       cy=(m&0x00200000)>>21;
	   key_routine();
	   scan_no++;
	   break;

case 2: m=IO1PIN;
       cy=(m&0x00400000)>>22;
	   key_routine();
	   scan_no++;
	   break;

case 3: m=IO1PIN;
       cy=(m&0x00800000)>>23;
	   key_routine();
	   //disp_blank();
	   scan_no++;
	   break;

case 4: IO1DIR=0x00020000;
       IO1CLR=0x00020000;
	   IO1SET=0x000D0000;
	   m=IO1PIN;
	   //IO0PIN=look_up[ds2-'0'];
	   cy=(m&0x00100000)>>20;
	   key_routine();
	   scan_no++;
	   break;

case 5: m=IO1PIN;
       cy=(m&0x00200000)>>21;
	   key_routine();
	   scan_no++;
	   break;

case 6: m=IO1PIN;
       cy=(m&0x00400000)>>22;
	   key_routine();
	   scan_no++;
	   break;

case 7: m=IO1PIN;
       cy=(m&0x00800000)>>23;
	   key_routine();
	   //disp_blank();
	   scan_no++;
	   break;

case 8: IO1DIR=0x00040000;
       IO1CLR=0x00040000;
	   IO1SET=0x000B0000;
	   m=IO1PIN;
	   //IO0PIN=look_up[ds3-'0'];
	   cy=(m&0x00100000)>>20;
	   key_routine();
	   scan_no++;
	   break;

case 9: m=IO1PIN;
       cy=(m&0x00200000)>>21;
	   key_routine();
	   scan_no++;
	   break;

case 10: m=IO1PIN;
       cy=(m&0x00400000)>>22;
	   key_routine();
	   scan_no++;
	   break;

case 11: m=IO1PIN;
       cy=(m&0x00800000)>>23;
	   key_routine();
	   //disp_blank();
	   scan_no++;
	   break;

case 12:IO1DIR=0x00080000;
       IO1CLR=0x00080000;
	   IO1SET=0x00070000;
	   m=IO1PIN;
	   //IO0PIN=look_up[ds4-'0'];
	   cy=(m&0x00100000)>>20;
	   key_routine();
	   scan_no++;
	   break;

case 13: m=IO1PIN;
       cy=(m&0x00200000)>>21;
	   key_routine();
	   scan_no++;
	   break;

case 14: m=IO1PIN;
       cy=(m&0x00400000)>>22;
	   key_routine();
	   scan_no++;
	   break;

case 15: m=IO1PIN;
       cy=(m&0x00800000)>>23;
	   key_routine();
	   //disp_blank();
	   scan_no=0;
	   break;
	}
   }

//void disp_blank()
//{
//IO0CLR=0x00ff0000;
//}

void key_routine()
{
if(key_ready==1)
out_debounce();
 else
   {
    if(dcount==33)
	 {
	  if(cy==1)
	  out_k();
	  else
	    {
		dcount--;
		key_code=scan_no;
		out_k();
		}
	   }
	  else
	  {
	   dcount--;
	   if(dcount==0)
	   {
	   if(cy==1)
	   {
	    dcount=33;
		out_k();
		}
	   else
	   {
	    dcount=33;
		key_ready=1;
		out_k();
		}
	   }
	  else
	  {
	  out_k();
	  }
	 }
	}
}

void out_debounce()
{
if(cy==1)
{
krcount--;
 if(krcount==0)
 {
  nkp=1;
  krcount=32;
  out_k();
  }
  else
   out_k();
   }
   else
   {
   krcount=32;
   out_k();
   }
   }
   void out_k()
   {
   }
      
void init_lcd(void)
{
delay_1ms(18);
lcd_cw(0x03);
delay_1ms(1);
lcd_cw(0x03);
delay_1ms(1);
lcd_cw(0x03);
delay_1ms(1);
lcd_cw(0x02);
delay_1ms(1);
lcd_cw(0x2c);
delay_1ms(1);
lcd_cw(0x10);
delay_1ms(1);
lcd_cw(0x0c);
delay_1ms(1);
lcd_cw(0x06);
delay_1ms(1);
lcd_cw(0x01);
delay_1ms(1);
IO0CLR=0x00010000;
}

void lcd_cw(unsigned int p)
{
delay_1ms(10);
IO0CLR=0x00ff0000;
IO0SET=(p & 0xF0)<<16;
IO0SET=0x00080000;
delay_1ms(1);
IO0CLR=0x00080000;
IO0CLR=0x00f00000;
IO0SET=(p&0x0f)<<20;
IO0SET=0x00080000;
delay_1ms(1);
IO0CLR=0x00080000;
}

void lcd_dw(unsigned int q)
{
delay_1ms(10);
IO0CLR=0x00ff0000;
IO0SET=0x00020000;
IO0CLR=0x00f00000;
IO0SET=(q&0xf0)<<16;
IO0SET=0x00080000;
delay_1ms(10);
IO0CLR=0x00080000;
IO0CLR=0x00f00000;
IO0SET=(q&0x0f)<<20;
IO0SET=0x00080000;
delay_1ms(10);
IO0CLR=0x00080000;
}

void delay_1ms(unsigned int t)
{
unsigned int i,j;
for(i=0;i<t;i++)
for(j=0;j<=120;j++);
}


