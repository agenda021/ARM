#include <LPC214X.H>
unsigned int ds1,ds2,ds3,ds4;
unsigned int key_code,temp,scan_no,dcount,krcount,m;
unsigned int cy,nkp,key_ready;
unsigned char look_up[]={"0123456789ABCDEF"};
unsigned char msg1[9]={"PRESS KEY"};
void init_keypad(void);
void timer(void);
void key_release(void);
void scanner(void);
void key_routine(void);
void out_debounce(void);
void disp_blank(void);
void out_k(void);  
void message(void);
void init_lcd(void);
void delay_1ms(unsigned int t);
void lcd_cw(unsigned int);
void lcd_dw(unsigned int);
void enable(void);
void lcd_display(void);

__irq void timer_isr_t0()
{
T0IR=0x01;
timer();
scanner();
VICVectAddr=0x00000000;
}

int main()
{
VPBDIV=0x00;
IO0DIR=0x00ff0000;
VICIntSelect=0x00000000;
VICIntEnable=0x00000010;
VICVectCntl0=0x00000024;
VICVectAddr0=(unsigned long)timer_isr_t0;
init_keypad();
timer();
init_lcd();
message();
while(1)
{
while(key_ready==0);
ds1=look_up[key_code];
lcd_display();
key_release();
}
}

void message()
{
 unsigned int i;
 lcd_cw(0x80);
 delay_1ms(1);
 for (i=0;i<9;i++)
 lcd_dw(msg1[i]);
}

void init_keypad()
{
IO1DIR=0x00f00000;
scan_no=0;
key_code=0;
dcount=33;
krcount=32;
key_ready=0;
nkp=0;
}

void timer()
{
T0TCR=0x01;
T0CTCR=0x00;
T0TC=0x00000000;
T0MR0=0x00003B2F;
T0PC=0x00000000;
T0MCR=0x0007;
}
void key_release()
{
while(nkp==0);
key_ready=0;
nkp=0;
}
void lcd_display()
{
 lcd_cw(0xC4);
 delay_1ms(1);
 lcd_dw(look_up[key_code]);
 delay_1ms(1);
}
void scanner()
{
switch(scan_no)
{
case 0: IO1DIR=0x00010000;
       IO1CLR=0x00010000;
	   IO1SET=0x000E0000;
	   m=IO1PIN;
	   IO0PIN=look_up[ds1-'0'];
	   cy=(m&0x00100000)>>20;
	   key_routine();
	   scan_no++;
	   break;

case 1: m=IO1PIN;
       cy=(m&0x00200000)>>21;
	   key_routine();
	   scan_no++;
	   break;

case 2: m=IO1PIN;
       cy=(m&0x00400000)>>22;
	   key_routine();
	   scan_no++;
	   break;

case 3: m=IO1PIN;
       cy=(m&0x00800000)>>23;
	   key_routine();
	   disp_blank();
	   scan_no++;
	   break;

case 4: IO1DIR=0x00020000;
       IO1CLR=0x00020000;
	   IO1SET=0x000D0000;
	   m=IO1PIN;
	   IO0PIN=look_up[ds2-'0'];
	   cy=(m&0x00100000)>>20;
	   key_routine();
	   scan_no++;
	   break;

case 5: m=IO1PIN;
       cy=(m&0x00200000)>>21;
	   key_routine();
	   scan_no++;
	   break;

case 6: m=IO1PIN;
       cy=(m&0x00400000)>>22;
	   key_routine();
	   scan_no++;
	   break;

case 7: m=IO1PIN;
       cy=(m&0x00800000)>>23;
	   key_routine();
	   disp_blank();
	   scan_no++;
	   break;

case 8: IO1DIR=0x00040000;
       IO1CLR=0x00040000;
	   IO1SET=0x000B0000;
	   m=IO1PIN;
	   IO0PIN=look_up[ds3-'0'];
	   cy=(m&0x00100000)>>20;
	   key_routine();
	   scan_no++;
	   break;

case 9: m=IO1PIN;
       cy=(m&0x00200000)>>21;
	   key_routine();
	   scan_no++;
	   break;

case 10: m=IO1PIN;
       cy=(m&0x00400000)>>22;
	   key_routine();
	   scan_no++;
	   break;

case 11: m=IO1PIN;
       cy=(m&0x00800000)>>23;
	   key_routine();
	   disp_blank();
	   scan_no++;
	   break;

case 12:IO1DIR=0x00080000;
       IO1CLR=0x00080000;
	   IO1SET=0x00070000;
	   m=IO1PIN;
	   IO0PIN=look_up[ds4-'0'];
	   cy=(m&0x00100000)>>20;
	   key_routine();
	   scan_no++;
	   break;

case 13: m=IO1PIN;
       cy=(m&0x00200000)>>21;
	   key_routine();
	   scan_no++;
	   break;

case 14: m=IO1PIN;
       cy=(m&0x00400000)>>22;
	   key_routine();
	   scan_no++;
	   break;

case 15: m=IO1PIN;
       cy=(m&0x00800000)>>23;
	   key_routine();
	   disp_blank();
	   scan_no=0;
	   break;
	}
   }



void out_debounce()
{
if(cy==1)
{
krcount--;
 if(krcount==0)
 {
  nkp=1;
  krcount=32;
  out_k();
  }
  else
   out_k();
   }
   else
   {
   krcount=32;
   out_k();
   }
   }
   void out_k()
   {
   }
      
void init_lcd(void)
{
delay_1ms(18);
lcd_cw(0x03);
delay_1ms(1);
lcd_cw(0x03);
delay_1ms(1);
lcd_cw(0x03);
delay_1ms(1);
lcd_cw(0x02);
delay_1ms(1);
lcd_cw(0x2c);
delay_1ms(1);
lcd_cw(0x10);
delay_1ms(1);
lcd_cw(0x0c);
delay_1ms(1);
lcd_cw(0x06);
delay_1ms(1);
lcd_cw(0x01);
delay_1ms(1);
IO0CLR=0x00010000;
}

void lcd_cw(unsigned int p)
{
delay_1ms(10);
IO0CLR=0x00ff0000;
IO0SET=(p & 0xF0)<<16;
IO0SET=0x00080000;
delay_1ms(1);
IO0CLR=0x00080000;
IO0CLR=0x00f00000;
IO0SET=(p&0x0f)<<20;
IO0SET=0x00080000;
delay_1ms(1);
IO0CLR=0x00080000;
}

void lcd_dw(unsigned int q)
{
delay_1ms(10);
IO0CLR=0x00ff0000;
IO0SET=0x00020000;
IO0CLR=0x00f00000;
IO0SET=(q&0xf0)<<16;
IO0SET=0x00080000;
delay_1ms(10);
IO0CLR=0x00080000;
IO0CLR=0x00f00000;
IO0SET=(q&0x0f)<<20;
IO0SET=0x00080000;
delay_1ms(10);
IO0CLR=0x00080000;
}

void delay_1ms(unsigned int t)
{
unsigned int i,j;
for(i=0;i<t;i++)
for(j=0;j<=120;j++);
}


