#include <LPC214X.H>
void delay(unsigned int t);
unsigned int a[]={0x00fc0000,0x00600000,0x00da0000,0x00f20000,0x00660000,0x00b60000,0x00be0000,0x00e00000,0x00fe0000,0x00f60000};
int ds1,ds2,ds3,ds4,m;
void display(void);
void decr(void);
int main()
{
VPBDIV=0X00;
IO0DIR=0X00ff0000;
ds1=ds2=ds3=ds4=9;
while(1)
{
for(m=1;m<=16;m++)
display();
decr();
}
}
void display()
{
IO1DIR=0X00010000;
IO0SET=a[ds1];
delay(20);
IO0CLR=a[ds1];
delay(20);
IO1DIR=0X00020000;
IO0SET=a[ds2];
delay(20);
IO0CLR=a[ds2];
delay(20);
IO1DIR=0X00040000;
IO0SET=a[ds3];
delay(20);
IO0CLR=a[ds3];
delay(20);
IO1DIR=0X00080000;
IO0SET=a[ds4];
delay(20);
IO0CLR=a[ds4];
delay(20);
}
void decr()
{
ds1--;
if(ds1==0-1)
{
ds1=9;
ds2--;
if(ds2==0-1)
{
ds2=9;
ds3--;
  if(ds3==0-1)
   {
    ds3=9;
    ds4--;
    if(ds4==0-1)
     ds4=9;
   }
}
}
}
void delay(unsigned int t)
{
unsigned int i,j;
{
for(i=0;i<=t;i++)
for(j=0;j<=1500;j++);
}
}

