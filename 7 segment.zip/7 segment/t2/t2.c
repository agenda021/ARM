#include <LPC214X.H>
void delay(unsigned int n);
int main()
{
VPBDIV=0X00;
IO0DIR=0X00FF0000;
while(1)
{
IO1DIR=0X00010000;
IO0SET=0X00fc0000;
delay(20);
IO0CLR=0X00fc0000;
delay(20);
IO1DIR=0X00020000;
IO0SET=0X00600000;
delay(20);
IO0CLR=0X00600000;
delay(20);
IO1DIR=0X00040000;
IO0SET=0X00DA0000;
delay(20);
IO0CLR=0X00DA0000;
delay(20);
IO1DIR=0X00080000;
IO0SET=0X00f20000;
delay(20);
IO0CLR=0X00f20000;
delay(20);
}
}
void delay(unsigned int n)
{
unsigned int i,j;
for(i=0;i<=n;i++)
for(j=0;j<=120;j++);
}
