#include <LPC214X.H>
#include<stdio.h>
void init_lcd(void);
void delay_1ms(unsigned int t);
void lcd_cw(unsigned int);
void lcd_dw(unsigned int);
void enable(void);
void display(void);
void incr(void);
unsigned char msg[7]={"UPCOUNT"};
unsigned char look_up[10]={"0123456789"};
unsigned int ds1,ds2,ds3,ds4;
int main()
{
unsigned int i;
VPBDIV=0X00;
IO0DIR=0X00FF0000;
init_lcd();
ds1=ds2=ds3=ds4=0;
lcd_cw(0x80);
for(i=0;i<=6;i++)
{
lcd_dw(msg[i]);
delay_1ms(60);
}
while(1)
{
display();
delay_1ms(400);
incr();
}
}

void display()
{
lcd_cw(0xc4);
lcd_dw(look_up[ds4]);
delay_1ms(5);
lcd_dw(look_up[ds3]);
delay_1ms(5);
lcd_dw(look_up[ds2]);
delay_1ms(5);
lcd_dw(look_up[ds1]);
delay_1ms(5);
}

void incr()
{
ds1++;
if(ds1==9+1)
{
ds1=0;
ds2++;
if(ds2==9+1)
{
ds2=0;
ds3++;
if(ds3==9+1)
{
ds3=0;
ds4++;
if(ds4==9+1)
ds4=0;
}
}
}
}

void init_lcd(void)
{
delay_1ms(18);
lcd_cw(0x03);
delay_1ms(1);
lcd_dw(0x03);
delay_1ms(1);
lcd_dw(0x03);
delay_1ms(1);
lcd_dw(0x02);
delay_1ms(1);
lcd_dw(0x10);
delay_1ms(1);
lcd_dw(0x10);
delay_1ms(1);
lcd_dw(0x0c);
delay_1ms(1);
lcd_dw(0x06);
delay_1ms(1);
lcd_dw(0x01);
delay_1ms(1);
IO0CLR=0X00010000;
}
void lcd_cw(unsigned int val)
{
delay_1ms(10);
IO0CLR=0x00ff0000;
IO0SET=(val&0xf0)<<16;
IO0SET=0x00080000;
delay_1ms(1);
IO0CLR=0x00080000;
IO0CLR=0x00ff0000;
IO0SET=(val&0x0f)<<20;
IO0SET=0x00080000;
delay_1ms(1);
IO0CLR=0x00080000;
}
void lcd_dw(unsigned int val1)
{
delay_1ms(10);
IO0CLR=0x00ff0000;
IO0SET=0x00020000;
IO0CLR=0x00f00000;
IO0SET=(val1&0xf0)<<16;
IO0SET=0x00080000;
delay_1ms(10);
IO0CLR=0x00080000;
IO0CLR=0x00f00000;
IO0SET=(val1&0x0f)<<20;
IO0SET=0x00080000;
delay_1ms(10);
IO0CLR=0x00080000;
}

void delay_1ms(unsigned int t)
{
unsigned int i,j;
for(i=0;i<t;i++)
{
for(j=0;j<=1500;j++);
}
}

