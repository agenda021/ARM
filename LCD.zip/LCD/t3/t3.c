#include <LPC214X.H>
#include<stdio.h>
void lcd(void);
void datawr(unsigned int);
void cmdwr(unsigned int);
void delay(unsigned int);
unsigned char a[]="HARITA";
unsigned int i,j;
int main()
{
VPBDIV=0x00;
IO0DIR=0X00ff0000;
lcd();
cmdwr(0x80);
delay(10);
for(i=0;i<6;i++)
{
datawr(a[i]);
delay(100);
}
	while(1)
	{
		cmdwr(0x18);
        delay(1000);
	 }
}

void lcd()
{
delay(18);
cmdwr(0x03);
delay(1);
cmdwr(0x03);
delay(1);
cmdwr(0x03);
delay(1);
cmdwr(0x02);
delay(1);
cmdwr(0x28);
delay(1);
cmdwr(0x06);
delay(1);
cmdwr(0x0c);
delay(1);
//cmdwr(0x0c);
//delay(1);
cmdwr(0x01);
delay(1);
IO0CLR=0X00010000;
}

void cmdwr(unsigned int val)
{
delay(10);
IO0CLR=0x00ff0000;
IO0SET=(val&0xf0)<<16;
IO0SET=0x00080000;
delay(1);
IO0CLR=0x00080000;
IO0CLR=0x00ff0000;
IO0SET=(val&0x0f)<<20;
IO0SET=0x00080000;
delay(1);
IO0CLR=0x00080000;
}

void datawr(unsigned int val1)
{
delay(10);
IO0CLR=0x00ff0000;
IO0SET=0x00020000;
IO0CLR=0x00f00000;
IO0SET=(val1&0xf0)<<16;
IO0SET=0x00080000;
delay(10);
IO0CLR=0x00080000;
IO0CLR=0x00f00000;
IO0SET=(val1&0x0f)<<20;
IO0SET=0x00080000;
delay(10);
IO0CLR=0x00080000;
}

void delay(unsigned int t)
{
unsigned int i,j;
for(i=0;i<t;i++)
{
for(j=0;j<=1500;j++);
}
}
